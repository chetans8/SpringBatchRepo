package com.hsm.springboot.mailnotificationservice;

import java.io.FileWriter;
import java.io.IOException;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

//File1.txt is converted in JSON File from object
public class MailAttachmentConfig {

	public static void main(String[] args) throws IOException {
 
		JSONObject obj = new JSONObject();
		obj.put("Name", "object tree");
		obj.put("Author", "App Shah");
 
		JSONArray company = new JSONArray();
		company.add("Company: eBay");
		company.add("Company: Paypal");
		company.add("Company: Google");
		obj.put("Company List", company);
 
		FileWriter file = new FileWriter("/Users/pc/Documents/file2.txt");
		try  {
			file.write(obj.toJSONString());
			System.out.println("Successfully Copied JSON Object to File...");
			System.out.println("\nJSON Object: " + obj);
		}catch (IOException e) {
			e.printStackTrace();
		}finally {
			file.flush();
			file.close();
		}
	}
	
}
